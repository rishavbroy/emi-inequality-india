# This file is part of the EMI inequality research pipeline.
# Functions are intentionally small enough to be tested and called by _targets.R.


#' clean nss 2017 education
#'
#' @return A tibble, model object, list, or file path depending on context.
clean_nss_2017_education <- function(raw) {
  raw
}

#' standardize edu1718 hhid
#'
#' @return A tibble, model object, list, or file path depending on context.
standardize_edu1718_hhid <- function(df) {
  df
}

#' standardize edu1718 district codes
#'
#' @return A tibble, model object, list, or file path depending on context.
standardize_edu1718_district_codes <- function(df) {
  df
}

#' standardize edu1718 weights
#'
#' @return A tibble, model object, list, or file path depending on context.
standardize_edu1718_weights <- function(df) {
  df
}

#' join 2017 state district labels
#'
#' @return A tibble, model object, list, or file path depending on context.
join_2017_state_district_labels <- function(df, districts, state_codes) {
  df
}

